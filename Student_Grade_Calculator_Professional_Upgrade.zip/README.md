# Student Grade Calculator – ReactJS

**Student:** BHAVANI T  
**Register No:** RA2411003050203

## Features
Dashboard, Add Student, automatic Total/Average/Grade, validation, Results, Search, Grade Filter, Edit, Delete and LocalStorage.

## Run
```bash
npm install
npm run dev
```

## GitHub
Upload all files in this folder to a GitHub repository. Do not upload `node_modules`.

## Vercel Live Demo
Import the GitHub repository into Vercel.
- Framework: Vite
- Build Command: `npm run build`
- Output Directory: `dist`

The included `vercel.json` supports React Router routes.
