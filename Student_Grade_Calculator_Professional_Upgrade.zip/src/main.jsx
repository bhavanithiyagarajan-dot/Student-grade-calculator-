import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import {BrowserRouter,NavLink,Route,Routes,useNavigate} from "react-router-dom";
import "./style.css";

const subjects=["Mathematics","Programming","Database Systems","Computer Networks","Machine Learning"];
const total=m=>m.reduce((a,b)=>a+Number(b||0),0);
const avg=m=>total(m)/subjects.length;
const grade=a=>a>=90?"A+":a>=80?"A":a>=70?"B":a>=60?"C":a>=50?"D":"F";
const status=a=>a>=50?"Passed":"Failed";

function App(){
 const [students,setStudents]=useState(()=>JSON.parse(localStorage.getItem("students")||"[]"));
 useEffect(()=>localStorage.setItem("students",JSON.stringify(students)),[students]);
 const add=s=>setStudents(x=>[...x,{...s,id:Date.now()}]);
 const update=s=>setStudents(x=>x.map(v=>v.id===s.id?s:v));
 const remove=id=>setStudents(x=>x.filter(v=>v.id!==id));
 return <div className="app">
  <header><div className="brand"><span className="brandIcon">🎓</span><div><b>GradeMate</b><small>Student Performance Portal</small></div></div>
   <nav><NavLink to="/" end>Dashboard</NavLink><NavLink to="/add">＋ Add Student</NavLink><NavLink to="/results">Results</NavLink></nav>
  </header>
  <main><Routes><Route path="/" element={<Dashboard students={students}/>}/><Route path="/add" element={<Add students={students} add={add}/>}/><Route path="/results" element={<Results students={students} update={update} remove={remove}/>/></Routes></main>
  <footer>Built with ReactJS • <strong>BHAVANI T</strong> • Student Grade Calculator</footer>
 </div>
}

function Dashboard({students}){
 const average=students.length?(students.reduce((a,s)=>a+avg(s.marks),0)/students.length):0;
 const pass=students.filter(s=>avg(s.marks)>=50).length;
 const top=students.length?Math.max(...students.map(s=>avg(s.marks))):0;
 return <div>
  <section className="hero"><div><span className="eyebrow">ACADEMIC PERFORMANCE</span><h1>Track. Calculate.<br/><em>Improve.</em></h1><p>A simple and professional way to manage student marks, grades and academic performance.</p><NavLink className="heroBtn" to="/add">Add Student <span>→</span></NavLink></div><div className="heroArt"><div className="scoreRing"><strong>{students.length?average.toFixed(0):"—"}</strong><span>Class Avg</span></div></div></section>
  <div className="cards"><Card icon="👥" title="Total Students" value={students.length}/><Card icon="📈" title="Class Average" value={average.toFixed(1)+"%"}/><Card icon="✅" title="Passed" value={pass}/><Card icon="🏆" title="Top Average" value={top?top.toFixed(1)+"%":"—"}/></div>
  <section className="panel"><div className="sectionHead"><div><span className="eyebrow dark">OVERVIEW</span><h2>Recent Results</h2></div><NavLink to="/results" className="textLink">View all →</NavLink></div><Table students={students.slice(-5).reverse()}/></section>
 </div>
}
function Card({icon,title,value}){return <div className="card"><span className="cardIcon">{icon}</span><div><small>{title}</small><strong>{value}</strong></div></div>}

function Add({students,add}){
 const nav=useNavigate(),[name,setName]=useState(""),[reg,setReg]=useState(""),[marks,setMarks]=useState(Array(5).fill("")),[err,setErr]=useState("");
 const ready=marks.every(x=>x!==""); const av=ready?avg(marks):0;
 function submit(e){e.preventDefault();setErr("");if(!name.trim()||!reg.trim()||!ready)return setErr("Please fill in all student details and marks.");if(marks.some(x=>Number(x)<0||Number(x)>100))return setErr("Each mark must be between 0 and 100.");if(students.some(s=>s.reg.toLowerCase()===reg.trim().toLowerCase()))return setErr("This register number already exists.");add({name:name.trim(),reg:reg.trim(),marks:marks.map(Number)});nav("/results")}
 return <section className="formPage"><div className="pageTitle"><span className="eyebrow dark">NEW RECORD</span><h1>Add Student</h1><p>Enter marks for five subjects. Results are calculated automatically.</p></div>
  <form className="panel formPanel" onSubmit={submit}><div className="grid2"><Field label="Student Name" value={name} setValue={setName} placeholder="e.g. Bhavani T"/><Field label="Register Number" value={reg} setValue={setReg} placeholder="e.g. RA2411003"/></div>
  <h3>Subject Marks <span> / 100</span></h3><div className="marks">{subjects.map((s,i)=><label key={s}><span>{s}</span><input type="number" min="0" max="100" placeholder="00" value={marks[i]} onChange={e=>setMarks(x=>x.map((v,j)=>j===i?e.target.value:v))}/></label>)}</div>
  <div className="liveResult"><div><small>Total Marks</small><b>{ready?total(marks):0}<i>/500</i></b></div><div><small>Average</small><b>{ready?av.toFixed(2):"0.00"}<i>%</i></b></div><div><small>Grade</small><b className={"bigGrade "+(ready?grade(av):"")}>{ready?grade(av):"—"}</b></div></div>
  {err&&<p className="error">⚠ {err}</p>}<button className="primaryBtn">Save Student <span>→</span></button></form>
 </section>
}
function Field({label,value,setValue,placeholder}){return <label className="field"><span>{label}</span><input value={value} onChange={e=>setValue(e.target.value)} placeholder={placeholder}/></label>}

function Table({students,onEdit,onDelete}){
 if(!students.length)return <div className="empty"><div>📋</div><b>No student records yet</b><span>Add a student to see results here.</span></div>;
 return <div className="tableWrap"><table><thead><tr><th>Student</th><th>Register No.</th><th>Total</th><th>Average</th><th>Grade</th>{onEdit&&<th>Action</th>}</tr></thead><tbody>{students.map(s=>{const a=avg(s.marks),g=grade(a);return <tr key={s.id}><td><div className="studentCell"><span>{s.name.charAt(0).toUpperCase()}</span><b>{s.name}</b></div></td><td>{s.reg}</td><td><b>{total(s.marks)}</b><small>/500</small></td><td>{a.toFixed(2)}%</td><td><b className={"badge "+g}>{g}</b></td>{onEdit&&<td><button className="mini" onClick={()=>onEdit(s)}>Edit</button><button className="mini danger" onClick={()=>onDelete(s.id)}>Delete</button></td>}</tr>})}</tbody></table></div>
}

function Results({students,update,remove}){
 const [q,setQ]=useState(""),[f,setF]=useState("All"),[edit,setEdit]=useState(null);
 const list=useMemo(()=>students.filter(s=>(s.name+" "+s.reg).toLowerCase().includes(q.toLowerCase())&&(f==="All"||grade(avg(s.marks))===f)),[students,q,f]);
 return <section><div className="pageTitle"><span className="eyebrow dark">ACADEMIC RECORDS</span><h1>Student Results</h1><p>Search, filter and manage all student performance records.</p></div>
 <div className="tools"><div className="search">⌕<input placeholder="Search by name or register number..." value={q} onChange={e=>setQ(e.target.value)}/></div><select value={f} onChange={e=>setF(e.target.value)}>{["All","A+","A","B","C","D","F"].map(x=><option key={x}>{x}</option>)}</select></div>
 <section className="panel"><div className="resultCount"><b>{list.length}</b> record{list.length!==1?"s":""} found</div><Table students={list} onEdit={setEdit} onDelete={remove}/></section>{edit&&<Edit s={edit} close={()=>setEdit(null)} save={update}/>}</section>
}
function Edit({s,close,save}){const [n,setN]=useState(s.name),[r,setR]=useState(s.reg),[m,setM]=useState(s.marks.map(String));return <div className="modal"><div className="modalbox"><div className="modalHead"><div><span className="eyebrow dark">UPDATE</span><h2>Edit Student</h2></div><button className="close" onClick={close}>×</button></div><Field label="Student Name" value={n} setValue={setN}/><Field label="Register Number" value={r} setValue={setR}/><div className="marks editMarks">{m.map((v,i)=><label key={i}><span>{subjects[i]}</span><input type="number" min="0" max="100" value={v} onChange={e=>setM(x=>x.map((z,j)=>j===i?e.target.value:z))}/></label>)}</div><button className="primaryBtn" onClick={()=>{save({...s,name:n.trim(),reg:r.trim(),marks:m.map(Number)});close()}}>Save Changes</button> <button className="secondary" onClick={close}>Cancel</button></div></div>}

createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);
