# Student Grade Calculator

A responsive Student Grade Calculator built using ReactJS, JavaScript ES6, HTML5 and CSS3.

## Features
- Dashboard with student statistics
- Add student with client-side validation
- Automatic total, average and grade calculation
- Search students
- Filter by grade
- Edit student records
- Delete student records
- Responsive design
- LocalStorage persistence
- Three functional views using React Router

## Grade Criteria
- 90–100: A+
- 80–89: A
- 70–79: B
- 60–69: C
- 50–59: D
- Below 50: F

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

## Production build

```bash
npm run build
npm run preview
```

## Deploy on Vercel
1. Upload this project to GitHub.
2. Go to Vercel and import the GitHub repository.
3. Framework: Vite.
4. Build command: `npm run build`
5. Output directory: `dist`
6. Deploy.

## Deploy on Netlify
1. Upload the project to GitHub.
2. Import the repository in Netlify.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy.

## Student
BHAVANI T
Department of Computer Science
SRM Institute of Technology
