import React, { useEffect, useMemo, useState } from "react";
import { NavLink, Route, Routes, useNavigate } from "react-router-dom";

const initialStudents = [
  { id: 1, name: "Anitha", regNo: "CS101", marks: [92, 86, 90, 88, 94] },
  { id: 2, name: "Kavin", regNo: "CS102", marks: [78, 82, 74, 80, 76] },
  { id: 3, name: "Priya", regNo: "CS103", marks: [64, 71, 68, 62, 70] }
];

const getTotal = (marks) => marks.reduce((sum, mark) => sum + Number(mark || 0), 0);
const getAverage = (marks) => getTotal(marks) / marks.length;

function getGrade(avg) {
  if (avg >= 90) return "A+";
  if (avg >= 80) return "A";
  if (avg >= 70) return "B";
  if (avg >= 60) return "C";
  if (avg >= 50) return "D";
  return "F";
}

function App() {
  const [students, setStudents] = useState(() => {
    const saved = localStorage.getItem("gradeStudents");
    return saved ? JSON.parse(saved) : initialStudents;
  });

  useEffect(() => {
    localStorage.setItem("gradeStudents", JSON.stringify(students));
  }, [students]);

  const addStudent = (student) => {
    setStudents((current) => [
      ...current,
      { ...student, id: Date.now() }
    ]);
  };

  const updateStudent = (updated) => {
    setStudents((current) =>
      current.map((student) => student.id === updated.id ? updated : student)
    );
  };

  const deleteStudent = (id) => {
    setStudents((current) => current.filter((student) => student.id !== id));
  };

  return (
    <div className="app-shell">
      <header className="navbar">
        <div className="brand">
          <div className="brand-icon">SG</div>
          <div>
            <h1>Student Grade Calculator</h1>
            <span>ReactJS Academic Management App</span>
          </div>
        </div>
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/add">Add Student</NavLink>
          <NavLink to="/results">Results</NavLink>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Dashboard students={students} />} />
          <Route
            path="/add"
            element={<AddStudent students={students} onAdd={addStudent} />}
          />
          <Route
            path="/results"
            element={
              <Results
                students={students}
                onUpdate={updateStudent}
                onDelete={deleteStudent}
              />
            }
          />
        </Routes>
      </main>

      <footer>Student Grade Calculator • Built with ReactJS, ES6 & CSS3</footer>
    </div>
  );
}

function Dashboard({ students }) {
  const averages = students.map((s) => getAverage(s.marks));
  const classAverage = averages.length
    ? (averages.reduce((a, b) => a + b, 0) / averages.length).toFixed(2)
    : "0.00";
  const passed = students.filter((s) => getAverage(s.marks) >= 50).length;
  const failed = students.length - passed;

  return (
    <section>
      <div className="hero">
        <div>
          <p className="eyebrow">ACADEMIC DASHBOARD</p>
          <h2>Manage student performance easily.</h2>
          <p>Enter marks, calculate results automatically, and manage student records from one responsive application.</p>
        </div>
        <div className="hero-badge">ReactJS</div>
      </div>

      <div className="stats-grid">
        <Stat title="Total Students" value={students.length} />
        <Stat title="Class Average" value={classAverage} />
        <Stat title="Passed" value={passed} />
        <Stat title="Failed" value={failed} />
      </div>

      <div className="panel">
        <div className="panel-header">
          <div>
            <h3>Recent Student Results</h3>
            <p>Automatically calculated from five subject marks.</p>
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Register No.</th><th>Total</th><th>Average</th><th>Grade</th></tr>
            </thead>
            <tbody>
              {students.length === 0 ? (
                <tr><td colSpan="5" className="empty">No student records available.</td></tr>
              ) : students.slice(-5).reverse().map((s) => {
                const avg = getAverage(s.marks);
                return (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td>{s.regNo}</td>
                    <td>{getTotal(s.marks)}/500</td>
                    <td>{avg.toFixed(2)}%</td>
                    <td><span className={`grade grade-${getGrade(avg).replace("+", "plus")}`}>{getGrade(avg)}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function Stat({ title, value }) {
  return (
    <div className="stat-card">
      <span>{title}</span>
      <strong>{value}</strong>
    </div>
  );
}

function AddStudent({ students, onAdd }) {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [regNo, setRegNo] = useState("");
  const [marks, setMarks] = useState(["", "", "", "", ""]);
  const [error, setError] = useState("");

  const total = marks.every((m) => m !== "") ? getTotal(marks) : 0;
  const average = marks.every((m) => m !== "") ? getAverage(marks) : 0;
  const grade = marks.every((m) => m !== "") ? getGrade(average) : "-";

  const handleMark = (index, value) => {
    if (value === "" || (/^\d{0,3}$/.test(value) && Number(value) <= 100)) {
      setMarks((current) => current.map((m, i) => i === index ? value : m));
    }
  };

  const submit = (e) => {
    e.preventDefault();
    const cleanName = name.trim();
    const cleanReg = regNo.trim();

    if (!cleanName || !cleanReg || marks.some((m) => m === "")) {
      setError("Please fill in all fields.");
      return;
    }
    if (marks.some((m) => Number(m) < 0 || Number(m) > 100)) {
      setError("Each mark must be between 0 and 100.");
      return;
    }
    if (students.some((s) => s.regNo.toLowerCase() === cleanReg.toLowerCase())) {
      setError("Register number already exists.");
      return;
    }

    onAdd({ name: cleanName, regNo: cleanReg, marks: marks.map(Number) });
    navigate("/results");
  };

  return (
    <section className="form-page">
      <div className="page-heading">
        <p className="eyebrow">STUDENT ENTRY</p>
        <h2>Add Student</h2>
        <p>Enter the five subject marks. Total, average and grade are calculated automatically.</p>
      </div>

      <form className="form-card" onSubmit={submit}>
        <div className="form-grid two">
          <label>Student Name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter student name" /></label>
          <label>Register Number<input value={regNo} onChange={(e) => setRegNo(e.target.value)} placeholder="e.g. CS104" /></label>
        </div>

        <h3>Subject Marks</h3>
        <div className="marks-grid">
          {["Subject 1", "Subject 2", "Subject 3", "Subject 4", "Subject 5"].map((subject, i) => (
            <label key={subject}>{subject}
              <input
                inputMode="numeric"
                value={marks[i]}
                onChange={(e) => handleMark(i, e.target.value)}
                placeholder="0 - 100"
              />
            </label>
          ))}
        </div>

        <div className="calculation-box">
          <div><span>Total</span><strong>{total}/500</strong></div>
          <div><span>Average</span><strong>{average.toFixed(2)}%</strong></div>
          <div><span>Grade</span><strong>{grade}</strong></div>
        </div>

        {error && <div className="error">{error}</div>}

        <button className="primary-btn" type="submit">Save Student</button>
      </form>
    </section>
  );
}

function Results({ students, onUpdate, onDelete }) {
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("All");
  const [editing, setEditing] = useState(null);

  const filtered = useMemo(() => {
    return students.filter((s) => {
      const avg = getAverage(s.marks);
      const grade = getGrade(avg);
      const matchesSearch =
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.regNo.toLowerCase().includes(search.toLowerCase());
      return matchesSearch && (gradeFilter === "All" || grade === gradeFilter);
    });
  }, [students, search, gradeFilter]);

  return (
    <section>
      <div className="page-heading">
        <p className="eyebrow">RESULT MANAGEMENT</p>
        <h2>Student Results</h2>
        <p>Search, filter, edit or delete student records.</p>
      </div>

      <div className="toolbar">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or register number..." />
        <select value={gradeFilter} onChange={(e) => setGradeFilter(e.target.value)}>
          <option>All</option>
          <option>A+</option><option>A</option><option>B</option><option>C</option><option>D</option><option>F</option>
        </select>
      </div>

      <div className="panel">
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Register</th><th>Total</th><th>Average</th><th>Grade</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="6" className="empty">No matching records.</td></tr>
              ) : filtered.map((s) => {
                const avg = getAverage(s.marks);
                const grade = getGrade(avg);
                return (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td>{s.regNo}</td>
                    <td>{getTotal(s.marks)}/500</td>
                    <td>{avg.toFixed(2)}%</td>
                    <td><span className={`grade grade-${grade.replace("+", "plus")}`}>{grade}</span></td>
                    <td className="actions">
                      <button onClick={() => setEditing(s)}>Edit</button>
                      <button className="danger" onClick={() => onDelete(s.id)}>Delete</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {editing && (
        <EditModal
          student={editing}
          onClose={() => setEditing(null)}
          onSave={(updated) => { onUpdate(updated); setEditing(null); }}
        />
      )}
    </section>
  );
}

function EditModal({ student, onClose, onSave }) {
  const [name, setName] = useState(student.name);
  const [regNo, setRegNo] = useState(student.regNo);
  const [marks, setMarks] = useState(student.marks.map(String));

  const save = (e) => {
    e.preventDefault();
    if (!name.trim() || !regNo.trim() || marks.some((m) => m === "" || Number(m) < 0 || Number(m) > 100)) return;
    onSave({ ...student, name: name.trim(), regNo: regNo.trim(), marks: marks.map(Number) });
  };

  return (
    <div className="modal-backdrop">
      <form className="modal" onSubmit={save}>
        <h3>Edit Student</h3>
        <label>Name<input value={name} onChange={(e) => setName(e.target.value)} /></label>
        <label>Register Number<input value={regNo} onChange={(e) => setRegNo(e.target.value)} /></label>
        <div className="marks-grid">
          {marks.map((mark, i) => (
            <label key={i}>Subject {i + 1}
              <input value={mark} onChange={(e) => setMarks((cur) => cur.map((m, idx) => idx === i ? e.target.value : m))} />
            </label>
          ))}
        </div>
        <div className="modal-actions">
          <button type="button" onClick={onClose}>Cancel</button>
          <button className="primary-btn" type="submit">Save Changes</button>
        </div>
      </form>
    </div>
  );
}

export default App;