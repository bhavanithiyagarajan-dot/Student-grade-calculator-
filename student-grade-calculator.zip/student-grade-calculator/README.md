# Student Grade Calculator (ReactJS + Vite)

## Run
    npm install
    npm run dev        # opens at http://localhost:5173

## Build
    npm run build

Views: Dashboard, Add Student (with validation and edit), Results (search, grade filter, edit, delete).
Data is saved in LocalStorage. Deploy: push to GitHub, then import the repo in Vercel or Netlify.
