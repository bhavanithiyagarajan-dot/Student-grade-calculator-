export function gradeOf(avg) {
  if (avg >= 90) return "A+";
  if (avg >= 80) return "A";
  if (avg >= 70) return "B";
  if (avg >= 60) return "C";
  if (avg >= 50) return "D";
  return "F";
}

export function calculate(marks) {
  const total = marks.reduce((sum, m) => sum + Number(m || 0), 0);
  const average = total / 5;
  return { total, average, grade: gradeOf(average) };
}
