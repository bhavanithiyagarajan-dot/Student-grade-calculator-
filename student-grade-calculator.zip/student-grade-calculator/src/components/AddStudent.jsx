import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { calculate } from "../grade.js";

export default function AddStudent({ students, setStudents }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const editing = students.find((s) => String(s.id) === id);

  const [name, setName] = useState(editing ? editing.name : "");
  const [reg, setReg] = useState(editing ? editing.reg : "");
  const [marks, setMarks] = useState(editing ? editing.marks.map(String) : ["", "", "", "", ""]);
  const [errors, setErrors] = useState({});

  const result = calculate(marks);

  const setMark = (i, value) => setMarks(marks.map((m, idx) => (idx === i ? value : m)));

  function validate() {
    const e = {};
    if (!name.trim()) e.name = "Name is required";
    if (!reg.trim()) e.reg = "Register number is required";
    else if (students.some((s) => s.reg.toLowerCase() === reg.trim().toLowerCase() && s !== editing))
      e.reg = "Register number already exists";
    marks.forEach((m, i) => {
      if (m === "" || isNaN(m) || m < 0 || m > 100) e["m" + i] = "0 to 100";
    });
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSubmit(ev) {
    ev.preventDefault();
    if (!validate()) return;
    const record = { id: editing ? editing.id : Date.now(), name: name.trim(), reg: reg.trim(), marks: marks.map(Number) };
    setStudents(editing ? students.map((s) => (s === editing ? record : s)) : [...students, record]);
    navigate("/results");
  }

  return (
    <>
      <small className="eyebrow">STUDENT ENTRY</small>
      <h1>{editing ? "Edit Student" : "Add Student"}</h1>
      <form className="card" onSubmit={handleSubmit} noValidate>
        <div className="grid2">
          <label>Student Name
            <input value={name} onChange={(e) => setName(e.target.value)} />
            {errors.name && <em>{errors.name}</em>}
          </label>
          <label>Register Number
            <input value={reg} onChange={(e) => setReg(e.target.value)} />
            {errors.reg && <em>{errors.reg}</em>}
          </label>
        </div>
        <div className="grid5">
          {marks.map((m, i) => (
            <label key={i}>Subject {i + 1}
              <input type="number" value={m} onChange={(e) => setMark(i, e.target.value)} />
              {errors["m" + i] && <em>{errors["m" + i]}</em>}
            </label>
          ))}
        </div>
        <div className="summary">
          <div><span>Total</span><b>{result.total}/500</b></div>
          <div><span>Average</span><b>{result.average.toFixed(2)}%</b></div>
          <div><span>Grade</span><b>{result.grade}</b></div>
        </div>
        <button type="submit">{editing ? "Update Student" : "Save Student"}</button>
      </form>
    </>
  );
}
