import { calculate } from "../grade.js";

export default function Dashboard({ students }) {
  const rows = students.map((s) => ({ ...s, ...calculate(s.marks) }));
  const classAvg = rows.length ? rows.reduce((a, r) => a + r.average, 0) / rows.length : 0;
  const passed = rows.filter((r) => r.grade !== "F").length;

  return (
    <>
      <section className="hero">
        <small>ACADEMIC DASHBOARD</small>
        <h1>Manage student performance easily.</h1>
      </section>
      <section className="stats">
        <div className="card"><span>Total Students</span><b>{rows.length}</b></div>
        <div className="card"><span>Class Average</span><b>{classAvg.toFixed(2)}</b></div>
        <div className="card"><span>Passed</span><b>{passed}</b></div>
        <div className="card"><span>Failed</span><b>{rows.length - passed}</b></div>
      </section>
      <section className="card">
        <h2>Recent Student Results</h2>
        {rows.slice(-5).reverse().map((r) => (
          <div className="row" key={r.id}>
            <span>{r.name}</span><span>{r.reg}</span>
            <span>{r.total}/500</span><span>{r.average.toFixed(2)}%</span>
            <b className="grade">{r.grade}</b>
          </div>
        ))}
        {rows.length === 0 && <p className="muted">No students yet.</p>}
      </section>
    </>
  );
}
