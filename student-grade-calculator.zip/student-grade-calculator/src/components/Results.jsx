import { useState } from "react";
import { Link } from "react-router-dom";
import { calculate } from "../grade.js";

export default function Results({ students, setStudents }) {
  const [query, setQuery] = useState("");
  const [grade, setGrade] = useState("All");

  const rows = students
    .map((s) => ({ ...s, ...calculate(s.marks) }))
    .filter((r) => (r.name + " " + r.reg).toLowerCase().includes(query.toLowerCase()))
    .filter((r) => grade === "All" || r.grade === grade);

  function remove(id) {
    if (window.confirm("Delete this student record?")) setStudents(students.filter((s) => s.id !== id));
  }

  return (
    <>
      <small className="eyebrow">RESULT MANAGEMENT</small>
      <h1>Student Results</h1>
      <div className="filters">
        <input placeholder="Search by name or register number..." value={query} onChange={(e) => setQuery(e.target.value)} />
        <select value={grade} onChange={(e) => setGrade(e.target.value)}>
          <option value="All">All grades</option>
          {["A+", "A", "B", "C", "D", "F"].map((g) => <option key={g}>{g}</option>)}
        </select>
      </div>
      <div className="card scroll">
        <table>
          <thead><tr><th>Name</th><th>Register</th><th>Total</th><th>Average</th><th>Grade</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>{r.name}</td><td>{r.reg}</td><td>{r.total}/500</td>
                <td>{r.average.toFixed(2)}%</td><td><b className="grade">{r.grade}</b></td>
                <td className="actions">
                  <Link to={"/edit/" + r.id}>Edit</Link>
                  <button className="link" onClick={() => remove(r.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="muted">No matching records.</p>}
      </div>
    </>
  );
}
