import { useEffect, useState } from "react";
import { NavLink, Route, Routes } from "react-router-dom";
import Dashboard from "./components/Dashboard.jsx";
import AddStudent from "./components/AddStudent.jsx";
import Results from "./components/Results.jsx";

const seed = [
  { id: 1, name: "Anitha", reg: "CS101", marks: [92, 86, 90, 88, 94] },
  { id: 2, name: "Kavin", reg: "CS102", marks: [80, 76, 78, 79, 77] },
  { id: 3, name: "Priya", reg: "CS103", marks: [70, 65, 68, 66, 66] },
  { id: 4, name: "Bhavani", reg: "CS104", marks: [92, 86, 90, 88, 94] },
];

export default function App() {
  const [students, setStudents] = useState(() => {
    const saved = localStorage.getItem("students");
    return saved ? JSON.parse(saved) : seed;
  });

  useEffect(() => {
    localStorage.setItem("students", JSON.stringify(students));
  }, [students]);

  return (
    <>
      <header className="nav">
        <div className="brand"><span className="logo">SG</span> Student Grade Calculator</div>
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/add">Add Student</NavLink>
          <NavLink to="/results">Results</NavLink>
        </nav>
      </header>
      <main className="page">
        <Routes>
          <Route path="/" element={<Dashboard students={students} />} />
          <Route path="/add" element={<AddStudent students={students} setStudents={setStudents} />} />
          <Route path="/edit/:id" element={<AddStudent students={students} setStudents={setStudents} />} />
          <Route path="/results" element={<Results students={students} setStudents={setStudents} />} />
        </Routes>
      </main>
    </>
  );
}
